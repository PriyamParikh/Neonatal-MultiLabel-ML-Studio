# Neonatal Multi-Label ML Studio

A locally hosted, custom HTML/CSS/JavaScript + Python/FastAPI application built from the capabilities of the user's original Classification ML Studio. **Research and software development only; not a medical device.** The sample CSV files are **synthetic, not real diagnosed neonatal cases**. Model accuracy on this demonstration material does not establish clinical utility or safety.

## Quick start (Windows, Python 3.11 recommended)

1. Extract **all** files from `Neonatal_MultiLabel_ML_Studio.zip` into one directory.
2. Double-click `RUN_ME_FIRST.bat`. It installs/checks dependencies, starts Python and opens the application.
3. If your browser doesn't open, go to **http://127.0.0.1:5000**. Keep the backend console open.
4. On the **Datasets** tab, upload `sample_data/training_2000_SYNTHETIC.csv` as training and `sample_data/testing_400_SYNTHETIC.csv` as testing.
5. On **Output Labels & Training**, keep **Multi-label classification** selected and select:
   - `sepsis_label` — Neonatal Sepsis
   - `rds_label` — Respiratory Distress Syndrome (RDS)
   - `nec_label` — Necrotizing Enterocolitis (NEC)
   - `ivh_label` — Intraventricular Hemorrhage (IVH)
   - `bpd_label` — Bronchopulmonary Dysplasia (BPD)
6. Select one or more algorithms (for a quick first test: Random Forest + Logistic Regression) and click **Train selected models**.
7. Inspect metrics, per-disease confusion matrices, ROC/PR curves, actual/predicted scatter plots, model feature importances, and optional SHAP results. Download reports and research models.

### Alternative start

```bat
python -m pip install -r requirements.txt
python app.py
```

On macOS/Linux, use `bash run_app.sh`, or run those two commands with `python3`.

## Supported classification modes

- **Multi-label**: select 1–25 **binary** outcome columns from the same patient table. Each must be 0/1, true/false, or yes/no. A patient may have more than one positive target. Each algorithm is fitted independently for each target. e.g. seven algorithms × five diseases gives up to 35 fitted pipelines. All targets and unselected label columns are removed from predictors automatically.
- **Single-target multiclass**: select exactly one column containing categorical values representing mutually exclusive classes. The same seven classifiers and plots remain available.

**Critical:** “Five classes” and “five simultaneous outcome labels” are different tasks. A neonatal patient can have both sepsis and RDS, so the five-label mode is generally the correct design here.

## Input format

One **row per baby** is strongly recommended for this version. Data in the training and testing files must share the selected predictor columns and target columns. CSV/XLSX/XLS formats supported. All five neonatal target columns can be selected, or columns can be chosen manually.

Columns like `record_id`, `patient_id`, `data_origin`, `simulated_disease_names`, and all recognised `*_label` outcome fields are automatically excluded from input predictors; additional exclusions are user-selectable. There is an automatic check that patient/record IDs in separately uploaded training and testing files do **not overlap**. When no test file is uploaded, the program performs an internal holdout; if repeated patient IDs are found, it uses a grouped split to avoid leakage.

Continuous-valued features are median-imputed and scaled, while categorical features are imputed and one-hot encoded; these preprocessors are **fitted on training data only** and applied to testing data. Optional training-only stratified CV. Target labels must be complete and clinically confirmed for a real cohort. The full dataset is never accidentally included in both train and test when an external testing file is provided.

## Algorithms

- Logistic Regression
- Decision Tree
- Random Forest
- Extra Trees
- K-Nearest Neighbors
- SVM (RBF)
- Bernoulli Naive Bayes

## Metrics and downloadable outputs

Individual disease × classifier: accuracy, balanced accuracy, macro precision/recall/F1, weighted F1, sensitivity, specificity, ROC AUC, average precision and classification report where defined.

Multi-label aggregate metrics: exact-match accuracy, Hamming loss, micro F1, macro F1. These measure all selected labels together; **exact-match accuracy is not the same as per-disease accuracy**.

Visualisations include confusion matrix, ROC curve, PR curve, PCA/SVD 2-D scatter (actual and predicted labels), native model feature importance for supported models, and optional SHAP beeswarm and SHAP global bar plots for Random Forest, Extra Trees, Decision Tree and Logistic Regression.

Available downloads: full metrics CSV, held-out predictions with actual + predicted + scores for each selected label, all-plots ZIP (for the selected algorithm across all diseases), and `.joblib` files containing one trained preprocessing/classifier pipeline plus feature metadata. Load joblib files **only from trusted sources** (pickle-based formats can execute arbitrary code).

## Important clinical and research limitations

1. The two included sample CSV files contain **artificial disease labels**, not confirmed patient diagnoses. They are intended for software testing; they cannot support claims about neonatal disease prediction or accuracy. Do not tune synthetic labels to achieve a target accuracy.
2. Even a high overall accuracy can conceal very poor recall for a relatively rare disease. Consider prevalence, per-disease sensitivity, specificity, precision-recall AUC, confidence intervals, calibration and external evaluation. The displayed probability score is **not** a clinically calibrated risk estimate.
3. Neonatal sepsis, RDS, NEC, IVH and BPD have different diagnostic criteria and observation windows. Clinical research must define the prediction time, outcome period, and qualifying disease evidence, and avoid predictors measured after diagnosis. In particular, BPD is a later endpoint.
4. Do not put any personally identifiable neonatal data into a sample CSV or research repo. With real hospital data, require institutional ethics/IRB approvals, de-identification, security review and appropriate access policies.
5. This version assumes a static feature snapshot for each infant. Multi-timepoint physiology/notes, longitudinal sequence models, probability calibration, nested tuning and deployment-grade access control should be added only after the clinically verified cohort and evaluation protocol are agreed.

## File structure

```
Neonatal_MultiLabel_ML_Studio/
  app.py                      # FastAPI API, ML, plots, safe train/test splitting
  templates/index.html       # Integrated responsive HTML, CSS, JS GUI
  requirements.txt
  RUN_ME_FIRST.bat            # Windows launcher
  run_app.bat                 # Alias for Windows launcher
  run_app.sh                  # macOS / Linux launcher
  sample_data/
    training_2000_SYNTHETIC.csv
    testing_400_SYNTHETIC.csv
```

The custom HTML interface is now explicitly included as `templates/index.html` (the original user upload contained backend/launcher files but not the template referenced by the original FastAPI application).

### Data privacy

The server listens only on `127.0.0.1:5000`, and the application performs no cloud API calls. Uploaded data are maintained in local process memory for the session and are cleared when the server stops. Only use the application on authorised machines with an approved data-handling protocol.
