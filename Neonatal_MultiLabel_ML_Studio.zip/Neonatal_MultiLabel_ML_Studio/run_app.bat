@echo off
call "%~dp0RUN_ME_FIRST.bat"
