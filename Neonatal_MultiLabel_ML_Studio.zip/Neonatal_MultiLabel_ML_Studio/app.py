"""Neonatal Multilabel ML Studio — research / education; not a medical device.

Each target column is an independent binary outcome in multi-label mode.
Single-target mode additionally permits ordinary multiclass classification.
Training and external testing datasets remain separate; no fitting on test records.
"""
from __future__ import annotations

import io
import os
import re
import threading
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from fastapi import FastAPI, File, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, Response
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score, balanced_accuracy_score, hamming_loss,
    classification_report, confusion_matrix, f1_score, precision_recall_curve, precision_score,
    recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import GroupShuffleSplit, StratifiedKFold, cross_val_score, train_test_split
from sklearn.naive_bayes import BernoulliNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, label_binarize
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

ROOT = Path(__file__).resolve().parent
app = FastAPI(title='Neonatal Multi-Label ML Studio', docs_url=None, redoc_url=None)
PLOT_LOCK = threading.RLock()
SESSIONS: dict[str, dict] = {}
JOBS: dict[str, 'TrainingJob'] = {}

DISEASE_LABELS = {'sepsis_label':'Neonatal Sepsis', 'rds_label':'Respiratory Distress Syndrome (RDS)',
                  'nec_label':'Necrotizing Enterocolitis (NEC)', 'ivh_label':'Intraventricular Hemorrhage (IVH)',
                  'bpd_label':'Bronchopulmonary Dysplasia (BPD)'}
MODEL_NAMES = ['Logistic Regression','Decision Tree','Random Forest','Extra Trees',
               'K-Nearest Neighbors','SVM (RBF)','Bernoulli Naive Bayes']
BLOCK_EXACT = {'simulated_disease_names', 'disease_names', 'diagnosis_names', 'data_origin',
               'patient_id', 'baby_id','record_id', 'subject_id', 'admission_id', 'hadm_id',
               'stay_id', 'id', 'class', 'diagnosis', 'outcome', 'disease', 'target'}
LABEL_REGEX = re.compile(r'(?:_label$|^label_|_target$|^target_|_outcome$|^outcome_|_diagnosis$|^diagnosis_)', re.I)

@dataclass
class FitResult:
    model: Pipeline
    predicted: np.ndarray
    probability: np.ndarray | None
    classes: np.ndarray
    metrics: dict
    report: list[dict]
    cv_f1_mean: float | None = None
    cv_f1_std: float | None = None

@dataclass
class TrainingJob:
    job_id: str
    mode: str
    source: str
    targets: list[str]
    features: list[str]
    X_train: pd.DataFrame
    X_test: pd.DataFrame
    Y_train: pd.DataFrame
    Y_test: pd.DataFrame
    results: dict[tuple[str, str], FitResult]
    leaderboard: pd.DataFrame
    multilabel_metrics: list[dict]
    notices: list[str]
    sample_defaults: dict
    synthetic: bool
    ids_test: list
    cache: dict[str, bytes] = field(default_factory=dict)


def display_target(t: str) -> str:
    return DISEASE_LABELS.get(t, t)


def make_models(seed: int, balanced: bool) -> dict:
    weight = 'balanced' if balanced else None
    return {
        'Logistic Regression': LogisticRegression(max_iter=2500, class_weight=weight, random_state=seed),
        'Decision Tree': DecisionTreeClassifier(max_depth=12, min_samples_leaf=2, class_weight=weight, random_state=seed),
        'Random Forest': RandomForestClassifier(n_estimators=150, min_samples_leaf=2, class_weight=weight, n_jobs=-1, random_state=seed),
        'Extra Trees': ExtraTreesClassifier(n_estimators=150, min_samples_leaf=2, class_weight=weight, n_jobs=-1, random_state=seed),
        'K-Nearest Neighbors': KNeighborsClassifier(n_neighbors=7, weights='distance'),
        'SVM (RBF)': SVC(probability=True, kernel='rbf', class_weight=weight, random_state=seed),
        'Bernoulli Naive Bayes': BernoulliNB(),
    }


def clean_frame(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        raise ValueError('Dataset contains no rows.')
    frame = frame.copy().dropna(axis=1, how='all')
    frame.columns = [str(x).strip() for x in frame.columns]
    if len(frame.columns) != len(set(frame.columns)):
        raise ValueError('Duplicate column names are not supported; please rename them.')
    return frame


def parse_csv_excel(data: bytes, name: str, sheet: str | None = None) -> tuple[pd.DataFrame, list[str]]:
    suffix = Path(name).suffix.lower()
    if suffix == '.csv':
        try:
            return clean_frame(pd.read_csv(io.BytesIO(data), low_memory=False)), []
        except UnicodeDecodeError:
            return clean_frame(pd.read_csv(io.BytesIO(data), encoding='latin-1', low_memory=False)), []
    if suffix in {'.xlsx', '.xls'}:
        with pd.ExcelFile(io.BytesIO(data)) as book:
            names = list(book.sheet_names)
            chosen = sheet or names[0]
            if chosen not in names:
                raise ValueError('Worksheet does not exist.')
            return clean_frame(pd.read_excel(book, sheet_name=chosen)), names
    raise ValueError('Only CSV, XLSX and XLS files are supported.')


def looks_like_label(col: str) -> bool:
    s = str(col).strip().lower()
    return s in DISEASE_LABELS or bool(LABEL_REGEX.search(s)) or s in {'label','target','outcome','diagnosis','class'}


def excluded_by_default(df: pd.DataFrame) -> list[str]:
    exclude = []
    for c in df.columns:
        low = c.lower()
        unique_ratio = df[c].nunique(dropna=True) / max(len(df), 1)
        if (looks_like_label(c) or low in BLOCK_EXACT or
            any(x in low for x in ['disease_names','diagnosis_name','free_text','progress_note',
                                   'doctor_note','nurse_note','discharge_summary','patient_name','mrn']) or
            (unique_ratio > 0.95 and any(s in low for s in ['_id', 'identifier', 'uuid']))):
            exclude.append(c)
    return exclude


def session_metadata(key: str, which: str, frame: pd.DataFrame, sheets: list[str]) -> dict:
    target_suggestions = [c for c in frame.columns if looks_like_label(c)]
    if not target_suggestions:
        target_suggestions = [c for c in frame.columns if str(c).lower() in {'diagnosis','class','outcome'}]
    return {'slot': which,'rows':len(frame),'columns':list(frame.columns), 'sheets':sheets,
            'suggested_targets':target_suggestions, 'suggested_ignore':excluded_by_default(frame),
            'missing':{c:int(frame[c].isna().sum()) for c in frame.columns},
            'preview':json_safe_records(frame.head(6))}


def json_safe(value):
    if isinstance(value, (np.integer,)): return int(value)
    if isinstance(value, (np.floating,)): value = float(value)
    if isinstance(value, (np.bool_,)): return bool(value)
    if value is None: return None
    try:
        if pd.isna(value): return None
    except (TypeError, ValueError): pass
    if isinstance(value, float) and not np.isfinite(value): return None
    if isinstance(value, (str, int, float, bool)): return value
    return str(value)


def json_safe_records(df: pd.DataFrame) -> list[dict]:
    return [{str(k):json_safe(v) for k,v in r.items()} for r in df.to_dict(orient='records')]


def preprocess_features(X_train: pd.DataFrame) -> ColumnTransformer:
    numeric = X_train.select_dtypes(include=['number','bool']).columns.tolist()
    categorical = [c for c in X_train.columns if c not in numeric]
    steps = []
    if numeric:
        steps.append(('numeric', Pipeline([('imputer',SimpleImputer(strategy='median', keep_empty_features=True)),
                                           ('scale',StandardScaler(with_mean=False))]), numeric))
    if categorical:
        steps.append(('categorical', Pipeline([('imputer',SimpleImputer(strategy='most_frequent',keep_empty_features=True)),
                                               ('onehot',OneHotEncoder(handle_unknown='ignore'))]), categorical))
    if not steps:
        raise ValueError('No predictor columns selected.')
    return ColumnTransformer(steps, remainder='drop', sparse_threshold=0.3)


def normalize_binary(series: pd.Series, column: str) -> pd.Series:
    if series.isna().any():
        raise ValueError(f"'{column}' contains missing diagnosis labels. Fill verified labels before training.")
    lowered = series.astype(str).str.strip().str.lower()
    allowed = {'1':1, '1.0':1, 'true':1, 'yes':1, 'positive':1,
               '0':0, '0.0':0, 'false':0, 'no':0, 'negative':0}
    invalid = sorted(set(lowered) - set(allowed))
    if invalid:
        raise ValueError(f"'{column}' must contain binary labels 0/1 (or yes/no); found: {invalid[:5]}.")
    return lowered.map(allowed).astype(int)


def positive_scores(fit: FitResult) -> np.ndarray | None:
    if fit.probability is None: return None
    if fit.probability.ndim != 2: return None
    classes = list(fit.classes)
    if len(classes) == 2:
        ix = classes.index(1) if 1 in classes else 1
        return fit.probability[:, ix]
    return None


def evaluate(y: pd.Series, predicted: np.ndarray, proba: np.ndarray | None, classes: np.ndarray) -> tuple[dict,list[dict]]:
    target_array = np.asarray(y)
    metrics = {'Accuracy':float(accuracy_score(target_array,predicted)),
               'Balanced Accuracy':float(balanced_accuracy_score(target_array,predicted)),
               'Precision (macro)':float(precision_score(target_array,predicted,average='macro',zero_division=0)),
               'Recall (macro)':float(recall_score(target_array,predicted,average='macro',zero_division=0)),
               'F1 (macro)':float(f1_score(target_array,predicted,average='macro',zero_division=0)),
               'F1 (weighted)':float(f1_score(target_array,predicted,average='weighted',zero_division=0)),
               'ROC AUC':None,'Average Precision':None}
    if len(classes) == 2:
        pos = 1 if 1 in list(classes) else classes[1]
        metrics['Sensitivity'] = float(recall_score(target_array,predicted,pos_label=pos,zero_division=0))
        metrics['Specificity'] = float(recall_score(target_array,predicted,pos_label=classes[0] if classes[0]!=pos else classes[1], zero_division=0))
        metrics['Positive prevalence'] = float((target_array==pos).mean())
    if proba is not None and proba.ndim == 2 and len(classes)==proba.shape[1]:
        try:
            if len(classes)==2 and len(np.unique(target_array))==2:
                pos = 1 if 1 in list(classes) else classes[1]
                positive_proba=proba[:,list(classes).index(pos)]
                truth=(target_array==pos).astype(int)
                metrics['ROC AUC']=float(roc_auc_score(truth,positive_proba))
                metrics['Average Precision']=float(average_precision_score(truth,positive_proba))
            elif len(classes)>2 and len(np.unique(target_array))==len(classes):
                metrics['ROC AUC']=float(roc_auc_score(target_array, proba,labels=classes,multi_class='ovr',average='macro'))
        except (ValueError,TypeError): pass
    report=classification_report(target_array, predicted, output_dict=True, zero_division=0)
    rows=[]
    for label,detail in report.items():
        if isinstance(detail,dict):
            rows.append({'class':str(label),'precision':round(detail['precision'],3),
                         'recall':round(detail['recall'],3),'f1':round(detail['f1-score'],3),
                         'support':int(detail['support']) if 'support' in detail and detail['support'] is not None else None})
    return metrics,rows


def check_ids(tr: pd.DataFrame, te: pd.DataFrame):
    for candidate in ['record_id','patient_id','baby_id','subject_id','id']:
        if candidate in tr and candidate in te:
            ids1=set(tr[candidate].dropna().astype(str))
            ids2=set(te[candidate].dropna().astype(str))
            both=ids1 & ids2
            if both:
                raise ValueError(f'Train/test patient leakage detected: {len(both)} shared {candidate} values. Separate babies before training.')


def prepare_job(payload: dict) -> TrainingJob:
    session_id=str(payload.get('session_id',''))
    session=SESSIONS.get(session_id)
    if session is None or 'train' not in session:
        raise ValueError('Upload a training dataset before training.')
    train=session['train']['frame'].copy()
    test=session.get('test',{}).get('frame')
    mode=str(payload.get('mode','multilabel'))
    if mode not in {'multilabel','multiclass'}:
        raise ValueError('Mode must be multilabel or multiclass.')
    targets=list(dict.fromkeys(str(c) for c in payload.get('targets',[])))
    if not targets or (mode=='multiclass' and len(targets)!=1):
        raise ValueError('Select at least one binary label, or exactly one multiclass target.')
    if len(targets)>25:
        raise ValueError('Limit analysis to 25 output targets per run.')
    absent=[c for c in targets if c not in train or (test is not None and c not in test)]
    if absent:
        raise ValueError('Selected output(s) missing from training or testing data: '+', '.join(absent))
    algos=list(dict.fromkeys(str(c) for c in payload.get('models',[])))
    if not algos or any(m not in MODEL_NAMES for m in algos):
        raise ValueError('Select at least one supported algorithm.')
    ignored=set(str(c) for c in payload.get('ignore',[]))
    compulsory=set(excluded_by_default(train)) | set(targets)
    # All label-like and outcome-name columns must be excluded, including unselected diseases.
    ignored |= compulsory
    requested_features=payload.get('features')
    if requested_features:
        features=[str(c) for c in requested_features if c in train and c not in ignored]
    else:
        features=[c for c in train.columns if c not in ignored]
    if not features:
        raise ValueError('No predictor features remain. Select clinical features and exclude output labels.')
    if test is not None:
        check_ids(train,test)
        missing=[c for c in features if c not in test]
        if missing: raise ValueError('Testing dataset is missing predictor columns: '+', '.join(missing))
    else:
        test_fraction=float(payload.get('test_fraction',.2))
        if not .1 <= test_fraction <= .5:
            raise ValueError('Test fraction should be 10–50%.')
        if len(train)<20: raise ValueError('Need at least 20 rows for an automatic holdout split.')
        # Group by patient ID where possible, so one baby never appears in both partitions.
        groups=None
        for candidate in ['record_id','patient_id','baby_id','subject_id']:
            if candidate in train and train[candidate].nunique(dropna=True)<len(train):
                groups=train[candidate].fillna('MISSING').astype(str)
                break
        seed=int(payload.get('seed',42))
        if groups is not None:
            groupsplit=GroupShuffleSplit(n_splits=1,test_size=test_fraction,random_state=seed)
            tr_i,te_i=next(groupsplit.split(train,groups=groups))
        else:
            primary = train[targets[0]]
            stratify = primary if mode=='multiclass' and primary.value_counts().min()>=2 else None
            tr_i,te_i=train_test_split(np.arange(len(train)),test_size=test_fraction,random_state=seed,stratify=stratify)
        test=train.iloc[te_i].copy()
        train=train.iloc[tr_i].copy()
    if len(train)<10 or len(test)<5:
        raise ValueError('Insufficient rows in training or testing data.')
    n_models=len(algos)*len(targets)
    if n_models>100:
        raise ValueError('Too many models requested (maximum 100 disease/model combinations).')
    X_train=train[features].copy().reset_index(drop=True)
    X_test=test[features].copy().reset_index(drop=True)
    for col in features:
        if pd.api.types.is_datetime64_any_dtype(X_train[col]):
            X_train[col]=X_train[col].astype(str)
            X_test[col]=X_test[col].astype(str)
        elif pd.api.types.is_object_dtype(X_train[col]) or pd.api.types.is_string_dtype(X_train[col]):
            X_train[col]=X_train[col].astype('string').astype(object).where(X_train[col].notna(), np.nan)
            X_test[col]=X_test[col].astype('string').astype(object).where(X_test[col].notna(), np.nan)
        else:
            X_train[col]=pd.to_numeric(X_train[col],errors='coerce')
            X_test[col]=pd.to_numeric(X_test[col],errors='coerce')
    # Remove wholly missing columns to avoid imputation artifacts.
    empty=[c for c in features if X_train[c].isna().all()]
    if empty:
        X_train.drop(columns=empty,inplace=True)
        X_test.drop(columns=empty,inplace=True)
        features=[c for c in features if c not in empty]
    if not features: raise ValueError('All predictor columns are empty.')
    ytr=pd.DataFrame(index=range(len(train)))
    yte=pd.DataFrame(index=range(len(test)))
    for target in targets:
        if mode=='multilabel':
            ytr[target]=normalize_binary(train[target].reset_index(drop=True),target)
            yte[target]=normalize_binary(test[target].reset_index(drop=True),target)
        else:
            if train[target].isna().any() or test[target].isna().any():
                raise ValueError('Multiclass target has missing labels.')
            ytr[target]=train[target].astype(str).reset_index(drop=True)
            yte[target]=test[target].astype(str).reset_index(drop=True)
        if ytr[target].nunique()<2:
            raise ValueError(f'Training labels for {target} contain only one class.')
        unseen=set(yte[target].unique())-set(ytr[target].unique())
        if unseen:
            raise ValueError(f'Test data for {target} contain class(es) not observed in training: {unseen}')
    seed=int(payload.get('seed',42))
    balanced=bool(payload.get('balanced',True))
    do_cv=bool(payload.get('cross_validation',False))
    cv_folds=int(payload.get('cv_folds',3))
    if cv_folds not in {3,4,5}: raise ValueError('Cross-validation folds must be 3, 4 or 5.')
    fits={}
    metric_rows=[]
    notices=[]
    if empty: notices.append('Dropped all-missing feature(s): '+', '.join(empty))
    if test is None: notices.append('Test records created by internal holdout split.')
    else: notices.append('Used separately uploaded held-out testing dataset; no re-splitting.')
    for target in targets:
        for algo in algos:
            estimator=make_models(seed,balanced)[algo]
            model=Pipeline([('preprocess',preprocess_features(X_train)),('model',estimator)])
            try:
                model.fit(X_train,ytr[target])
                pred=np.asarray(model.predict(X_test))
                probability=np.asarray(model.predict_proba(X_test)) if hasattr(model,'predict_proba') else None
                classes=np.asarray(model.named_steps['model'].classes_)
                metrics,report=evaluate(yte[target],pred,probability,classes)
                cv_mean=cv_std=None
                if do_cv:
                    min_count=int(ytr[target].value_counts().min())
                    folds=min(min_count,cv_folds)
                    if folds>=2:
                        cvs=cross_val_score(clone(model),X_train,ytr[target],cv=StratifiedKFold(n_splits=folds,shuffle=True,random_state=seed),scoring='f1_macro',n_jobs=1)
                        cv_mean,cv_std=float(cvs.mean()),float(cvs.std())
                result=FitResult(model,pred,probability,classes,metrics,report,cv_mean,cv_std)
                fits[target,algo]=result
                metric_rows.append({'Disease / Target':display_target(target),'Target':target,'Model':algo,
                                    **metrics,'Train N':len(X_train),'Test N':len(X_test),
                                    'CV F1 mean':cv_mean,'CV F1 std':cv_std})
            except Exception as exc:
                notices.append(f'{target} / {algo} failed: {str(exc)[:190]}')
    if not fits:
        raise ValueError('No selected models trained successfully. '+ ' '.join(notices[-4:]))
    defaults={}
    for col in features:
        s=X_train[col].dropna()
        if pd.api.types.is_numeric_dtype(X_train[col]):
            defaults[col]={'type':'number','value':json_safe(s.median()) if len(s) else None}
        else:
            choices=[str(v) for v in s.value_counts().index[:15]]
            defaults[col]={'type':'categorical','value':choices[0] if choices else '', 'choices':choices}
    is_synthetic=(any('SYNTHETIC' in str(session.get(k,{}).get('filename','')).upper() for k in ['train','test']) or
                  ('data_origin' in train and train['data_origin'].astype(str).str.contains('SYNTHETIC',case=False,na=False).any()))
    if is_synthetic:
        notices.insert(0,'SYNTHETIC DATA DETECTED: metrics cannot be interpreted as clinical validation.')
    if mode=='multilabel':
        notices.append('Multi-label: each disease is fitted and scored independently; multiple positive outcomes are allowed.')
    multi_summary=[]
    if mode=='multilabel':
        for algo in algos:
            if all((t,algo) in fits for t in targets):
                truth_mat=np.column_stack([yte[t].to_numpy() for t in targets])
                pred_mat=np.column_stack([fits[t,algo].predicted for t in targets])
                multi_summary.append({'Model':algo,'Exact-match accuracy':float(accuracy_score(truth_mat,pred_mat)),
                    'Hamming loss':float(hamming_loss(truth_mat,pred_mat)),
                    'F1 micro':float(f1_score(truth_mat,pred_mat,average='micro',zero_division=0)),
                    'F1 macro':float(f1_score(truth_mat,pred_mat,average='macro',zero_division=0))})
    job=TrainingJob(uuid.uuid4().hex,mode,
                    'External test upload' if 'test' in session else 'Internal holdout',
                    targets,features,X_train,X_test,ytr,yte,fits,
                    pd.DataFrame(metric_rows),multi_summary,notices,defaults,is_synthetic,
                    test[[c for c in ['record_id','patient_id','baby_id','subject_id'] if c in test][0]].astype(str).tolist()
                    if any(c in test for c in ['record_id','patient_id','baby_id','subject_id']) else list(range(len(test))))
    JOBS[job.job_id]=job
    return job


def fetch_result(job: TrainingJob, target: str, model_name: str) -> FitResult:
    result=job.results.get((target,model_name))
    if result is None: raise ValueError('Unknown combination of output target and algorithm.')
    return result


def create_plot(job: TrainingJob, target: str, model_name: str, kind: str) -> bytes:
    key=f'{target}|{model_name}|{kind}'
    if key in job.cache: return job.cache[key]
    r=fetch_result(job,target,model_name)
    truth=np.asarray(job.Y_test[target]); pred=r.predicted
    with PLOT_LOCK:
        fig,ax=plt.subplots(figsize=(8,5.8))
        caption=f'{display_target(target)} — {model_name}'
        if kind=='confusion':
            cm=confusion_matrix(truth,pred,labels=r.classes)
            ax.imshow(cm,cmap='Blues')
            ax.set_xticks(range(len(r.classes)),[str(c) for c in r.classes]); ax.set_yticks(range(len(r.classes)),[str(c) for c in r.classes])
            for i in range(len(r.classes)):
                for j in range(len(r.classes)):
                    ax.text(j,i,str(cm[i,j]),ha='center',va='center',color='white' if cm[i,j]>cm.max()/2 else '#172c42',fontsize=11)
            ax.set_xlabel('Predicted');ax.set_ylabel('Actual')
            ax.set_title(f'Confusion matrix — {caption}')
        elif kind in {'roc','pr'}:
            if r.probability is None: raise ValueError('Model did not return probability estimates.')
            if len(r.classes)==2:
                pos=1 if 1 in list(r.classes) else r.classes[1]
                pos_idx=list(r.classes).index(pos)
                y=(truth==pos).astype(int)
                if len(np.unique(y))<2: raise ValueError('This test set has only one class; ROC/PR is not defined.')
                labels=[(str(pos),y,r.probability[:,pos_idx])]
            else:
                labels=[(str(cl),(truth==cl).astype(int),r.probability[:,i]) for i,cl in enumerate(r.classes) if 0<(truth==cl).sum()<len(truth)]
            for classlabel,y,scores in labels:
                if kind=='roc':
                    fpr,tpr,_=roc_curve(y,scores)
                    ax.plot(fpr,tpr,label=f'{classlabel} (AUC={roc_auc_score(y,scores):.3f})')
                else:
                    precision,recall,_=precision_recall_curve(y,scores)
                    ax.plot(recall,precision,label=f'{classlabel} (AP={average_precision_score(y,scores):.3f})')
            if kind=='roc':
                ax.plot([0,1],[0,1],'--',color='#999',lw=1)
                ax.set_xlabel('False positive rate');ax.set_ylabel('Sensitivity / TPR');ax.set_title(f'ROC — {caption}')
            else:
                ax.set_xlabel('Recall');ax.set_ylabel('Precision');ax.set_title(f'Precision–Recall — {caption}')
                if len(r.classes)==2: ax.axhline(y.mean(),ls=':',color='#aaa',label='Positive prevalence')
            ax.legend(fontsize=9);ax.grid(alpha=.2)
        elif kind in {'scatter_true','scatter_pred'}:
            transformed=r.model.named_steps['preprocess'].transform(job.X_test)
            if transformed.shape[1]<2:
                dense=transformed.toarray() if hasattr(transformed,'toarray') else np.asarray(transformed)
                xy=np.column_stack([dense[:,0],np.zeros(len(dense))]); reduction='Single feature'
            elif hasattr(transformed,'toarray'):
                xy=TruncatedSVD(n_components=2,random_state=42).fit_transform(transformed);reduction='TruncatedSVD'
            else:
                xy=PCA(n_components=2,random_state=42).fit_transform(np.asarray(transformed));reduction='PCA'
            coloring=truth if kind=='scatter_true' else pred
            for cls in pd.unique(coloring):
                mask=np.asarray(coloring)==cls
                ax.scatter(xy[mask,0],xy[mask,1],label=str(cls),s=18,alpha=.7)
            ax.set_xlabel(f'{reduction} component 1');ax.set_ylabel(f'{reduction} component 2');ax.grid(alpha=.15)
            ax.legend();ax.set_title(f'Scatter ({"actual" if kind=="scatter_true" else "predicted"}) — {caption}')
        elif kind=='importance':
            # Extract native tree importances, aggregated back to original feature names.
            estimator=r.model.named_steps['model']
            transformer=r.model.named_steps['preprocess']
            if hasattr(estimator,'feature_importances_'):
                importances=np.asarray(estimator.feature_importances_)
            elif hasattr(estimator,'coef_'):
                importances=np.mean(np.abs(estimator.coef_),axis=0)
            else:
                raise ValueError('Importance plot is available for tree and logistic-regression models only.')
            names=np.asarray(transformer.get_feature_names_out())
            order=np.argsort(importances)[-20:]
            ax.barh(np.arange(len(order)),importances[order],color='#4d8cbc')
            ax.set_yticks(np.arange(len(order)),[str(names[i]).replace('numeric__','').replace('categorical__','')[:58] for i in order])
            ax.set_xlabel('Model feature importance (preprocessed features)')
            ax.set_title(f'Features — {caption}')
        else: raise ValueError('Unknown plot type.')
        fig.tight_layout()
        buf=io.BytesIO();fig.savefig(buf,format='png',dpi=160,bbox_inches='tight');plt.close(fig)
    job.cache[key]=buf.getvalue()
    return job.cache[key]


def predict_row(job: TrainingJob, model_name: str, vals: dict) -> list[dict]:
    row={}
    for c in job.features:
        value=vals.get(c,None)
        if value in ('',None): value=np.nan
        if job.sample_defaults[c]['type']=='number':
            try: value=float(value)
            except (ValueError,TypeError): value=np.nan
        else:
            if not pd.isna(value): value=str(value)
        row[c]=value
    X=pd.DataFrame([row])[job.features]
    out=[]
    for t in job.targets:
        r=job.results.get((t,model_name))
        if r is None: continue
        value=json_safe(r.model.predict(X)[0]); prob=None
        if hasattr(r.model,'predict_proba'):
            ps=r.model.predict_proba(X)[0]
            if len(r.classes)==2:
                pos=1 if 1 in list(r.classes) else r.classes[1]
                prob=float(ps[list(r.classes).index(pos)])
            else:
                prob=float(np.max(ps))
        out.append({'target':t,'name':display_target(t),'predicted':value,'score':prob})
    return out


def shap_plots(job: TrainingJob, target: str, model_name: str) -> dict[str, bytes]:
    """On-demand SHAP plots for supported tree/linear classifiers, capped sample size."""
    first=f'{target}|{model_name}|shap_beeswarm'
    second=f'{target}|{model_name}|shap_global'
    if first in job.cache and second in job.cache:
        return {'shap_beeswarm':job.cache[first],'shap_global':job.cache[second]}
    try:
        import shap
    except ImportError as exc:
        raise ValueError('SHAP is not installed. Run pip install -r requirements.txt.') from exc
    r=fetch_result(job,target,model_name)
    clf=r.model.named_steps['model']
    if not isinstance(clf,(RandomForestClassifier,ExtraTreesClassifier,DecisionTreeClassifier,LogisticRegression)):
        raise ValueError('SHAP beeswarm is supported for Random Forest, Extra Trees, Decision Tree and Logistic Regression.')
    pre=r.model.named_steps['preprocess']
    names=[str(x).replace('numeric__','').replace('categorical__','') for x in pre.get_feature_names_out()]
    if len(names)>250: raise ValueError('SHAP limited to 250 transformed features for performance.')
    tr=job.X_train.head(45)
    te=job.X_test.head(60)
    a=pre.transform(tr);b=pre.transform(te)
    a=a.toarray() if hasattr(a,'toarray') else np.asarray(a)
    b=b.toarray() if hasattr(b,'toarray') else np.asarray(b)
    if isinstance(clf,LogisticRegression):
        explainer=shap.LinearExplainer(clf,a)
    else:
        explainer=shap.TreeExplainer(clf)
    values=explainer(b)
    if np.asarray(values.values).ndim==3:
        ix=list(r.classes).index(1) if 1 in list(r.classes) else min(1,len(r.classes)-1)
        values=values[:,:,ix]
    values.feature_names=names
    output={}
    with PLOT_LOCK:
        for kind in ['shap_beeswarm','shap_global']:
            plt.close('all')
            if kind=='shap_beeswarm':
                shap.plots.beeswarm(values,max_display=18,show=False)
            else:
                shap.plots.bar(values,max_display=18,show=False)
            fig=plt.gcf();fig.set_size_inches(9,6)
            fig.suptitle(f'{kind.replace("_"," ").title()} — {display_target(target)} | {model_name}',y=1.03,fontsize=13)
            fig.tight_layout()
            buf=io.BytesIO();fig.savefig(buf,format='png',dpi=160,bbox_inches='tight')
            plt.close(fig)
            output[kind]=buf.getvalue()
            job.cache[f'{target}|{model_name}|{kind}']=output[kind]
    return output


def download(content: bytes, filename: str, mediatype: str) -> Response:
    safe=re.sub('[^a-zA-Z0-9_.-]','_',filename)
    return Response(content,media_type=mediatype,headers={'Content-Disposition':f'attachment; filename="{safe}"','Cache-Control':'no-store'})


def to_csv(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode('utf-8-sig')


def predictions_frame(job: TrainingJob, model_name: str) -> pd.DataFrame:
    df=pd.DataFrame({'record_id':job.ids_test})
    for t in job.targets:
        r=job.results.get((t,model_name))
        if r is None: continue
        df[f'actual__{t}']=np.asarray(job.Y_test[t]);df[f'predicted__{t}']=r.predicted
        if r.probability is not None:
            if len(r.classes)==2:
                pos=1 if 1 in list(r.classes) else r.classes[1]
                df[f'score_positive__{t}']=r.probability[:,list(r.classes).index(pos)]
            else:
                for i,c in enumerate(r.classes):
                    df[f'probability__{t}__{c}']=r.probability[:,i]
    return df


def as_job(job_id: str) -> TrainingJob:
    if job_id not in JOBS: raise ValueError('Training job not found. Train again after restarting the server.')
    return JOBS[job_id]


def error(exc: Exception):
    return JSONResponse({'ok':False,'error':str(exc)},status_code=400)


@app.get('/',response_class=HTMLResponse)
def index():
    return HTMLResponse((ROOT/'templates'/'index.html').read_text(encoding='utf-8'))

@app.get('/health')
def health():
    return {'ok':True,'service':'neonatal-multilabel-ml-studio'}

@app.post('/api/upload/{which}')
async def upload(which: str,file: UploadFile=File(...),session_id: str=''):
    try:
        if which not in {'train','test'}: raise ValueError('Use train or test upload.')
        if Path(file.filename or '').suffix.lower() not in {'.csv','.xlsx','.xls'}:
            raise ValueError('Upload CSV/XLSX/XLS only.')
        raw=await file.read()
        if len(raw)>60*1024*1024: raise ValueError('Maximum file size is 60MB.')
        frame,sheets=parse_csv_excel(raw,file.filename or 'data.csv')
        sid=session_id if session_id in SESSIONS else uuid.uuid4().hex
        SESSIONS.setdefault(sid,{})[which]={'frame':frame,'raw':raw,'filename':file.filename,'sheets':sheets}
        return {'ok':True,'session_id':sid,'metadata':session_metadata(sid,which,frame,sheets)}
    except Exception as exc: return error(exc)

@app.post('/api/sheet')
async def choose_sheet(request: Request):
    try:
        p=await request.json(); sid=p['session_id'];which=p['slot']
        entry=SESSIONS[sid][which]
        frame,sheets=parse_csv_excel(entry['raw'],entry['filename'],p['sheet'])
        entry['frame']=frame
        return {'ok':True,'metadata':session_metadata(sid,which,frame,sheets)}
    except Exception as exc: return error(exc)

@app.post('/api/train')
async def train(request: Request):
    try:
        job=prepare_job(await request.json())
        return {'ok':True,'job_id':job.job_id,'mode':job.mode,'targets':job.targets,
                'algorithms':list(dict.fromkeys(a for _,a in job.results)),
                'leaderboard':json_safe_records(job.leaderboard),'multilabel_summary':job.multilabel_metrics,
                'rows_train':len(job.X_train),'rows_test':len(job.X_test),
                'features':job.features,'notices':job.notices,'synthetic':job.synthetic,
                'patient_form':job.sample_defaults}
    except Exception as exc: return error(exc)

@app.get('/api/job/{job_id}/report')
def report(job_id: str,target: str,model: str):
    try:
        job=as_job(job_id);r=fetch_result(job,target,model)
        return {'ok':True,'report':r.report,'metrics':r.metrics,'classes':[json_safe(c) for c in r.classes]}
    except Exception as exc: return error(exc)

@app.get('/api/job/{job_id}/plot')
def plot(job_id: str,target: str,model: str,kind: str):
    try: return Response(create_plot(as_job(job_id),target,model,kind),media_type='image/png',headers={'Cache-Control':'no-store'})
    except Exception as exc: return error(exc)

@app.get('/api/job/{job_id}/download/{kind}')
def download_job(job_id: str,kind: str,model: str='Random Forest',target: str='',plot: str='confusion'):
    try:
        job=as_job(job_id)
        if kind=='metrics': return download(to_csv(job.leaderboard),'all_models_metrics.csv','text/csv')
        if kind=='predictions': return download(to_csv(predictions_frame(job,model)),f'{model}_test_predictions.csv','text/csv')
        if kind=='model':
            r=fetch_result(job,target,model)
            bundle={'pipeline':r.model,'target':target,'features':job.features,
                    'mode':job.mode,'classes':r.classes.tolist(),
                    'research_only':True,'synthetic_training':job.synthetic}
            out=io.BytesIO();joblib.dump(bundle,out)
            return download(out.getvalue(),f'{target}_{model}_model.joblib','application/octet-stream')
        if kind=='plot':
            content=shap_plots(job,target,model)[plot] if plot in {'shap_beeswarm','shap_global'} else create_plot(job,target,model,plot)
            return download(content,f'{target}_{model}_{plot}.png','image/png')
        if kind=='all_plots':
            out=io.BytesIO()
            with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
                z.writestr('all_models_metrics.csv',to_csv(job.leaderboard))
                z.writestr('heldout_predictions.csv',to_csv(predictions_frame(job,model)))
                for target_name in job.targets:
                    if (target_name,model) not in job.results: continue
                    for kindname in ['confusion','roc','pr','scatter_true','scatter_pred','importance']:
                        try: z.writestr(f'{target_name}/{kindname}.png',create_plot(job,target_name,model,kindname))
                        except Exception: pass
                z.writestr('NOTICE.txt',('RESEARCH SOFTWARE ONLY. Synthetic datasets are not clinical data.\n'
                         +'Do not use outputs to diagnose or treat newborns.\n').encode())
            return download(out.getvalue(),f'{model}_all_diseases_graphs.zip','application/zip')
        raise ValueError('Invalid download option.')
    except Exception as exc: return error(exc)

@app.get('/api/job/{job_id}/shap')
def get_shap(job_id: str,target: str,model: str,kind: str='shap_beeswarm'):
    try:
        if kind not in {'shap_beeswarm','shap_global'}: raise ValueError('Unknown SHAP plot.')
        return Response(shap_plots(as_job(job_id),target,model)[kind],media_type='image/png',headers={'Cache-Control':'no-store'})
    except Exception as exc: return error(exc)

@app.post('/api/job/{job_id}/predict')
async def predict(job_id: str,request: Request):
    try:
        p=await request.json();job=as_job(job_id)
        return {'ok':True,'synthetic':job.synthetic,'outputs':predict_row(job,p['model'],p.get('values',{}))}
    except Exception as exc: return error(exc)


if __name__=='__main__':
    import uvicorn
    port=int(os.environ.get('PORT','5000'))
    print(f'\nNeonatal Multi-Label ML Studio — http://127.0.0.1:{port}\n')
    uvicorn.run(app,host='127.0.0.1',port=port,log_level='info')
