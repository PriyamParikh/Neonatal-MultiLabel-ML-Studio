@echo off
setlocal
cd /d "%~dp0"
title Neonatal Multi-Label ML Studio Launcher
echo ========================================================
echo   NEONATAL MULTI-LABEL ML STUDIO
 echo   localhost only ^| research software
 echo ========================================================
echo.
where python >nul 2>nul
if errorlevel 1 (
  echo Python is not found. Install Python 3.11 or later with PATH enabled.
  pause
  exit /b 1
)
echo Checking or installing dependencies...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Dependency installation failed; see the error above.
  pause
  exit /b 1
)
echo Starting backend...
start "Neonatal ML Backend - KEEP OPEN" cmd /k "cd /d ""%~dp0"" && python app.py"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; for($i=0;$i -lt 80;$i++){ try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:5000/health' -TimeoutSec 1; if($r.service -eq 'neonatal-multilabel-ml-studio'){$ok=$true;break} } catch {}; Start-Sleep -Milliseconds 500 }; if($ok){exit 0}else{exit 1}"
if errorlevel 1 (
 echo Backend did not respond. Check the backend terminal window.
 pause
 exit /b 1
)
start "" http://127.0.0.1:5000
echo Opened http://127.0.0.1:5000
exit /b 0
