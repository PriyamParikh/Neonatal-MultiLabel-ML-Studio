#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt
( sleep 3 && python3 -c "import webbrowser; webbrowser.open('http://127.0.0.1:5000')" ) &
python3 app.py
